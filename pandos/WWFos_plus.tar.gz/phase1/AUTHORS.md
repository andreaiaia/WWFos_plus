# This is the list of  WWFos_plus' contributors.

Andrea Bianchi <andrea.bianchi20@studio.unibo.it>
Niccolò Alfonso Cicioni <niccolo.cicioni@studio.unibo.it>
Alex Lorenzato <alex.lorenzato@studio.unibo.it>