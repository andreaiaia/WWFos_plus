#ifndef INIT_PROC_H
#define INIT_PROC_H

#include "inclusive.h"
#include "vmSupport.h"
#include "sysSupport.h"


extern void initSwapStructs();

void test_fase3();

#endif