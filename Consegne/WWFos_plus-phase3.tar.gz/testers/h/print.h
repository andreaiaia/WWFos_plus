#ifndef PRINTIT
#define PRINTIT

/************************** PRINT.H ******************************
*
*  Written by Mikeyg
*/

extern void print (int device, char *str);

/***************************************************************/

#endif
